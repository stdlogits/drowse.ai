export declare const DROWSE_HOOK_ABI: "block-sites-v5";
export declare const DROWSE_EXACT_READOUT_ABI: "exact-readout-v2";
export type DrowsePositionSpan = [number, number];
export interface DrowsePositionSelection {
    position_spans?: readonly (readonly [number, number])[] | null;
    position_indices?: readonly number[] | null;
}
/** Absolute input-token positions, zero-based and end-exclusive. */
export declare function normalizeDrowsePositionSelection(selection: DrowsePositionSelection): DrowsePositionSpan[] | undefined;
export interface DrowseRuntimeCapabilities {
    positionSpans?: boolean;
    topK: boolean;
    forcedReplay: boolean;
    replayScoring: boolean;
    tokenizer: boolean;
    namedRoles: boolean;
    userSeatGeneration: boolean;
    sceneStitching: boolean;
}
export declare const DROWSE_READOUT_TOP_K = 8;
export interface DrowseSaeDictionary {
    hookAbi: typeof DROWSE_HOOK_ABI;
    bindingId: string;
    hiddenSize: number;
    runtimeLayerIndex: number;
    featureCount: number;
    activation: "relu" | "jump_relu";
    encoder: Float32Array;
    encoderBias: Float32Array;
    encoderThreshold: Float32Array;
    decoderBias: Float32Array;
}
export interface DrowseJlensDictionary {
    hookAbi: typeof DROWSE_HOOK_ABI;
    bindingId: string;
    hiddenSize: number;
    layerIndices: Int32Array;
    matrices: readonly Float32Array[];
}
export interface DrowseJlensTopTokenReadout {
    tokenIds: Int32Array;
    strength: Float32Array;
    centerOfMass: Float32Array;
    spread: Float32Array;
    fittedLayerCount: number;
    layerIndices: Int32Array;
    layerTokenIds: Int32Array;
    layerProbabilities: Float32Array;
}
export interface DrowseSaeTopFeatureReadout {
    featureIds: Int32Array;
    activations: Float32Array;
    runtimeLayerIndex: number;
    featureCount: number;
}
export interface DrowseMeasurementBundle {
    scalar?: Float32Array;
    /** The live unit tap of the last forward (`[DROWSE_UNIT_MAX_TAPS]`, slot order), when the
     *  installed program has a unit section. */
    unitTaps?: Float32Array;
    /** The last forward's `[L, d]` block-output capture at its last row (row-major), when the
     *  installed program asks for it (`hiddenCapture`): `slens/` probes and gates read it on the
     *  host post-forward (HOOK_ABI §5). */
    hidden?: Float32Array;
    geometry?: Float32Array;
    jlensTopTokens?: DrowseJlensTopTokenReadout;
    saeTopFeatures?: DrowseSaeTopFeatureReadout;
}
export type DrowseStructuredProfileId = "standard-v4" | "standard-v4-residual";
export interface DrowseStructuredHookProfile {
    schemaVersion: 4;
    id: DrowseStructuredProfileId;
    /** 1 when the library compiles the in-block unit sites (`standard-v4`). */
    unitSites: 0 | 1;
    /** The library's whole schema-4 descriptor, for the caller's element-by-element attestation
     *  against the model's lock entry (block spec, context, capacities). */
    descriptor: number[];
    hookAbi: typeof DROWSE_HOOK_ABI;
    format: typeof DROWSE_STRUCTURED_HOOK_FORMAT;
    layerCount: number;
    hiddenSize: number;
    maxAffineGroups: number;
    maxRank: number;
    maxProbes: number;
    maxCurves: number;
    maxCurveNodes: number;
    maxIntrinsicDim: number;
    maxEmbedDim: number;
    curveParameterStride: number;
    maxComputeWorkgroupStorageSize: number;
    maxGeometryProbes: number;
    maxWhitenerRank: number;
    maxGeometryCandidates: number;
    geometryOutputStride: number;
    geometryFootRestarts: number;
    geometryFootIterations: number;
    geometryWarmRestarts: number;
    geometryWarmIterations: number;
    requiredMaxStorageBuffersPerShaderStage: number;
    geometryKernelStorageBindings: number;
    geometryHeaderStride: number;
    geometryPayloadElements: number;
    exactReadoutAbiVersion: 2;
    exactReadoutAbi: typeof DROWSE_EXACT_READOUT_ABI;
    readoutTopK: number;
    maxSaeFeaturesPerChunk: number;
}
export declare const DROWSE_STRUCTURED_HOOK_FORMAT: "drowse-structured-v4";
export type DrowseStructuredHookFormat = typeof DROWSE_STRUCTURED_HOOK_FORMAT;
export declare const DROWSE_STRUCTURED_MAX_AFFINE_GROUPS = 4;
export declare const DROWSE_STRUCTURED_MAX_RANK = 8;
export declare const DROWSE_STRUCTURED_MAX_PROBES = 8;
export declare const DROWSE_STRUCTURED_MAX_CURVES = 4;
export declare const DROWSE_STRUCTURED_MAX_CURVE_NODES = 32;
export declare const DROWSE_STRUCTURED_MAX_INTRINSIC_DIM = 4;
export declare const DROWSE_STRUCTURED_MAX_EMBED_DIM = 8;
export declare const DROWSE_STRUCTURED_CURVE_PARAMETER_STRIDE = 671;
export declare const DROWSE_STRUCTURED_MAX_GEOMETRY_PROBES = 8;
export declare const DROWSE_STRUCTURED_MAX_WHITENER_RANK = 96;
export declare const DROWSE_STRUCTURED_MAX_GEOMETRY_CANDIDATES = 33;
export declare const DROWSE_STRUCTURED_GEOMETRY_OUTPUT_STRIDE = 41;
export declare const DROWSE_STRUCTURED_GEOMETRY_FOOT_RESTARTS = 3;
export declare const DROWSE_STRUCTURED_GEOMETRY_FOOT_ITERATIONS = 12;
export declare const DROWSE_STRUCTURED_GEOMETRY_WARM_RESTARTS = 2;
export declare const DROWSE_STRUCTURED_GEOMETRY_WARM_ITERATIONS = 4;
export declare const DROWSE_STRUCTURED_GEOMETRY_HEADER_STRIDE = 7;
export declare const DROWSE_STRUCTURED_GEOMETRY_KERNEL_STORAGE_BINDINGS = 8;
export declare const DROWSE_STRUCTURED_REQUIRED_MAX_STORAGE_BUFFERS_PER_SHADER_STAGE = 8;
export declare const DROWSE_STRUCTURED_PROFILE_SCHEMA_VERSION: 4;
export declare const DROWSE_STRUCTURED_PROFILE_ID: "standard-v4";
export declare const DROWSE_STRUCTURED_RESIDUAL_PROFILE_ID: "standard-v4-residual";
export declare const DROWSE_STRUCTURED_PROFILE_MAGIC = 1396788044;
/** Descriptor schema 4: v3's 31 fields, then the block spec and unit capacities (HOOK_ABI.md §6). */
export declare const DROWSE_STRUCTURED_PROFILE_DESCRIPTOR_LENGTH = 67;
export declare const DROWSE_HOOK_PROFILE_ID_FIELD: 4;
export declare const DROWSE_HOOK_ABI_VERSION: 5;
export declare const DROWSE_STRUCTURED_FORMAT_VERSION: 4;
export declare const DROWSE_EXACT_READOUT_ABI_VERSION: 2;
/** Descriptor indices the bridge itself reads (the rest is attested by the caller). */
export declare const DROWSE_DESCRIPTOR_UNIT_SITES = 31;
export declare const DROWSE_DESCRIPTOR_D_FF = 32;
export declare const DROWSE_DESCRIPTOR_N_Q_HEADS = 33;
export declare const DROWSE_DESCRIPTOR_N_KV_HEADS = 34;
export declare const DROWSE_DESCRIPTOR_HEAD_DIM = 35;
export declare const DROWSE_DESCRIPTOR_ROPE_IN_GRAPH = 48;
export declare const DROWSE_DESCRIPTOR_ANATOMY_STRIDE = 61;
export declare const DROWSE_DESCRIPTOR_PREFILL_CHUNK_SIZE = 51;
export declare const DROWSE_DESCRIPTOR_CONTEXT_TOKENS = 66;
/** Unit capacities of `standard-v4` (B1 §3.1, §3.5). */
export declare const DROWSE_UNIT_MAX_GROUPS = 4;
export declare const DROWSE_UNIT_MAX_NEURON_ABLATIONS = 256;
export declare const DROWSE_UNIT_MAX_HEAD_ABLATIONS = 64;
export declare const DROWSE_UNIT_MAX_TAPS = 64;
export declare const DROWSE_UNIT_MAX_HEAD_TAPS = 16;
/** The unit pair every `standard-v4` library exports and every residual library lacks. */
export declare const DROWSE_UNIT_FUNCTIONS: readonly ["drowse_units_batch_prefill", "drowse_units_batch_decode", "drowse_replay_batch_prefill", "drowse_attention_rows", "drowse_head_write_grams"];
/** Replay capacities of `standard-v4` (B1 §2.3, §6; HOOK_ABI.md §7). */
export declare const DROWSE_UNIT_MAX_ACTIVITY_TRACES = 32;
export declare const DROWSE_UNIT_MAX_ACTIVITY_SPANS = 4;
export declare const DROWSE_UNIT_MAX_PATTERN_LAYERS = 16;
export declare const DROWSE_UNIT_MAX_PATTERN_HEADS = 16;
export declare const DROWSE_REPLAY_FLAG_ANATOMY = 1;
export declare const DROWSE_REPLAY_FLAG_ACTIVITY = 2;
export declare const DROWSE_REPLAY_FLAG_PATTERNS = 4;
/** `replay_meta` offsets (HOOK_ABI.md §7, drowse.ai `replayMetaLayout`). */
export declare const DROWSE_REPLAY_META: Readonly<{
    anatomyPosition: 0;
    spanCount: 1;
    spans: 2;
    populationRow: number;
    traceCount: number;
    traces: number;
    patternLayerCount: number;
    patternLayers: number;
    flags: number;
    length: number;
}>;
/** The block-sites device surface the drowse.ai adapter drives (HOOK_ABI.md §7-§9), one
 *  request per call so the worker engine carries it as one message kind. */
/** The block-sites requests that may run while a generation stream holds the model lock (between
 *  its tokens): static reads and resident uploads and releases. Replays own the KV cache and wait. */
export declare const DROWSE_STREAMING_BLOCK_SITES_OPS: ReadonlySet<DrowseBlockSitesRequest["op"]>;
export type DrowseBlockSitesRequest = {
    op: "headGrams";
} | {
    op: "uploadUnitScales";
    values: Float32Array;
} | {
    op: "release";
    id: string;
} | {
    op: "openReplay";
    replayMeta: Int32Array;
    unitScales: string | null;
    rowCount: number;
    /** The positions the replay will feed (≤ the context): sizes the pattern keys. */
    tokenCount: number;
} | {
    op: "replayForward";
    tokenIds: number[];
    affineActive?: Uint32Array;
    curveActive?: Uint32Array;
    unitActive?: Float32Array;
} | {
    op: "finishReplay";
} | {
    op: "cancelReplay";
} | {
    op: "attentionRows";
    capture: string;
    rows: Int32Array;
} | {
    op: "uploadResident";
    kind: "lens_layer" | "embedding_statistics";
    /** `lens_layer`: `[1, d, d]` fp32. `embedding_statistics`: `mean_E [d]`, `Σ_E [d, d]` fp32
     *  and the token mask `[ceil(V / 32)]` uint32. */
    tensors: DrowseTensorInput[];
} | {
    op: "read";
    steps: DrowseReadStep[];
    read: string[];
};
export interface DrowseResidentHandle {
    id: string;
    kind: "head_grams" | "unit_scales" | "pattern_capture" | "lens_layer" | "embedding_statistics";
    shape: number[];
    bytes: number;
}
/** A host tensor crossing into the bridge; its dtype follows the array type. */
export interface DrowseTensorInput {
    data: Float32Array | Int32Array | Uint32Array;
    shape: number[];
}
/** A tensor read back from the device. */
export interface DrowseTensorOutput {
    data: Float32Array | Int32Array | Uint32Array;
    shape: number[];
}
/** One argument of a static-read step: a host tensor uploaded for the call, a resident buffer
 *  (`index` picks a tensor of a multi-tensor resident; head grams by their resident id), or an
 *  earlier step's output; `shape` views it (same element count). */
export type DrowseReadArg = {
    tensor: DrowseTensorInput;
} | {
    resident: string;
    index?: number;
    shape?: number[];
} | {
    ref: string;
    shape?: number[];
};
/** One static-read call (HOOK_ABI.md §8): `fn` from `DROWSE_READOUT_FUNCTIONS` or (units
 *  libraries) `DROWSE_UNIT_READ_FUNCTIONS`, its outputs named for later steps and the readback. */
export interface DrowseReadStep {
    fn: string;
    args: DrowseReadArg[];
    out: string | string[];
}
export interface DrowseReadOutputs {
    tensors: Record<string, DrowseTensorOutput>;
}
/** `exact-readout-v2`: every block-sites-v5 library exports these. */
export declare const DROWSE_READOUT_FUNCTIONS: readonly ["drowse_embedding_rows", "drowse_unembedding_rows", "drowse_vocab_logits", "drowse_footprint_scores", "drowse_logit_moments", "drowse_log_sum_exp", "drowse_topk", "drowse_batched_matmul", "drowse_batched_matmul_nt", "drowse_quadratic_form", "drowse_grouped_row_norms", "drowse_chan_merge"];
/** The unit static reads: exactly the libraries with unit sites export these. */
export declare const DROWSE_UNIT_READ_FUNCTIONS: readonly ["drowse_neuron_rows", "drowse_head_rows", "drowse_layer_write_scores", "drowse_layer_read_scores", "drowse_neuron_contributions", "drowse_head_contributions", "drowse_head_write_norms", "drowse_gather_head_grams", "drowse_unembed_cotangent"];
/** Static reads that take the model parameters (the others are weight-free). */
export declare const DROWSE_PACKED_READ_FUNCTIONS: ReadonlySet<string>;
/** At most this many steps per read request. */
export declare const DROWSE_MAX_READ_STEPS = 256;
export interface DrowseReplayForwardReadback {
    /** `[L, maxProbes]` probe slots of the segment's last forward (kind-3 slots hold the
     *  J-lens probability, as the measurement bundle's). */
    measurements: Float32Array;
    /** `[maxUnitTaps]` raw unit taps of the segment's last forward. */
    unitTaps: Float32Array;
    /** `[L, maxGeometryProbes, geometryOutputStride]` geometry readout of the segment's last
     *  forward, or null when the program has no geometry probes. */
    geometry: Float32Array | null;
    /** `[L, d]` capture of the segment's last forward when the program sets `hiddenCapture`,
     *  else null. */
    hidden: Float32Array | null;
}
export interface DrowseReplayCaptures {
    /** `[L, ANATOMY_STRIDE]` at the anatomy position, or null when not asked. */
    anatomyTaps: Float32Array | null;
    /** `[L, 3·d_ff + 3·H]`, `[32, rowCount]`, `[L, d_ff + H]`, or null when not asked. */
    activityState: Float32Array | null;
    traces: Float32Array | null;
    population: Float32Array | null;
    /** Keys and queries kept resident for `attentionRows`, or null when not asked. */
    patterns: DrowseResidentHandle | null;
}
export type DrowseBlockSitesResult = DrowseReadOutputs | DrowseResidentHandle | DrowseReplayForwardReadback | DrowseReplayCaptures | Float32Array | null;
/** Fail closed on a `replay_meta` the kernels would index by (HOOK_ABI.md §7). */
export declare function validateDrowseReplayMeta(meta: Int32Array, model: {
    layerCount: number;
    dFF: number;
    nHeads: number;
    contextTokens: number;
    rowCount: number;
    tokenCount: number;
}): number;
/** `unit_meta` (u32) and `unit_coeff` (f32) lengths for a model (HOOK_ABI.md §4). */
export declare function drowseUnitSectionLengths(layerCount: number, headDim: number): {
    meta: number;
    coeff: number;
    active: number;
    tapGrams: number;
};
export declare const DROWSE_EXACT_READOUT_MAX_SAE_FEATURES_PER_CHUNK = 16384;
export declare const DROWSE_STRUCTURED_MIN_COMPUTE_WORKGROUP_STORAGE_SIZE: number;
export declare function drowseGeometryPayloadElements(layerCount: number, hiddenSize: number): number;
export declare function decodeDrowseStructuredHookProfile(values: ArrayLike<number>, expectedLayerCount: number, expectedHiddenSize: number): DrowseStructuredHookProfile;
export interface DrowseStructuredProgram extends DrowsePositionSelection {
    hookAbi: typeof DROWSE_HOOK_ABI;
    format: DrowseStructuredHookFormat;
    hiddenSize: number;
    layerCount: number;
    affineActive: Uint32Array;
    affineBasis: Float32Array;
    affineNeutral: Float32Array;
    affineTarget: Float32Array;
    affineAlong: Float32Array;
    affineKappa: Float32Array;
    probeKind: Uint32Array;
    probeDirection: Float32Array;
    probeBias: Float32Array;
    probeThreshold: Float32Array;
    curveActive: Uint32Array;
    curveRank: Uint32Array;
    curveIntrinsicDim: Uint32Array;
    curveEmbedDim: Uint32Array;
    curveNodeCount: Uint32Array;
    curveBasis: Float32Array;
    curveNeutral: Float32Array;
    curveNodeParameters: Float32Array;
    curveRbfWeights: Float32Array;
    curvePolynomial: Float32Array;
    curveCoordinateOffset: Float32Array;
    curveCoordinateScale: Float32Array;
    curveOrigin: Float32Array;
    curveTarget: Float32Array;
    curveAlong: Float32Array;
    curveOnto: Float32Array;
    curveBounds: Float32Array;
    curveAxisPeriodic: Uint32Array;
    curveAxisPeriod: Float32Array;
    curveSigmaPresent: Uint32Array;
    curveSigmaRbfWeights: Float32Array;
    curveSigmaPolynomial: Float32Array;
    curveDamping: Float32Array;
    curveDomainKind?: Uint32Array;
    whitenerRank?: Uint32Array;
    whitenerRidge?: Float32Array;
    whitenerBasis?: Float32Array;
    whitenerCorrection?: Float32Array;
    geometryActive?: Uint32Array;
    geometryKind?: Uint32Array;
    geometryRank?: Uint32Array;
    geometryIntrinsicDim?: Uint32Array;
    geometryCandidateCount?: Uint32Array;
    geometryCurveNodeCount?: Uint32Array;
    geometryDomainKind?: Uint32Array;
    geometryMean?: Float32Array;
    geometryInverseMean?: Float32Array;
    geometryBasis?: Float32Array;
    geometryGramInverse?: Float32Array;
    geometryCholesky?: Float32Array;
    geometryNodeWhite?: Float32Array;
    geometryCoordMap?: Float32Array;
    geometryCoordBias?: Float32Array;
    geometryCurveParameters?: Float32Array;
    geometryCurveNodeCoords?: Float32Array;
    geometryCurveNodeValues?: Float32Array;
    geometryFeet?: Float32Array;
    jLensBindingId?: string;
    jLensLayerIndices?: Int32Array;
    jLensReadoutLayerIndices?: Int32Array;
    jLensTokenIds?: Int32Array;
    saeBindingId?: string;
    /** Keep each forward's `[L, d]` capture for the host (the measurement bundle's `hidden`). */
    hiddenCapture?: boolean;
    /** drowse-structured-v4's unit section (B1 §3.1, §3.4): present together or not at all. */
    unitMeta?: Uint32Array;
    unitCoeff?: Float32Array;
    unitActive?: Float32Array;
    tapGrams?: Float32Array;
}
/** Whether a program carries a unit section (validated by `validateDrowseUnitSection`). */
export declare function drowseProgramHasUnits(program: DrowseStructuredProgram): boolean;
/** The unit section's presence, lengths, CSR offsets and indices (fail closed; the GPU kernels
 *  index by these values). */
export declare function validateDrowseUnitSection(program: DrowseStructuredProgram, layerCount: number, headDim: number, dFF: number, nHeads: number): void;
export declare function packDrowseCurveParameters(program: DrowseStructuredProgram): Float32Array;
export declare function updatePackedDrowseCurveActive(packed: Float32Array, active: Uint32Array): void;
export declare function packDrowseGeometryHeader(program: DrowseStructuredProgram): Uint32Array;
export declare function packDrowseGeometryPayload(program: DrowseStructuredProgram): Float32Array;
export interface DrowseResidualCapture {
    layerCount: number;
    positionCount: number;
    hiddenSize: number;
    positions: number[];
    values: Float32Array;
}
export interface DrowseCaptureMessage {
    role: "system" | "user" | "assistant";
    content: string;
    roleName?: string;
}
export interface DrowseCaptureRow {
    system: string;
    messages: DrowseCaptureMessage[];
}
export interface DrowsePreparedCaptureRow {
    inputIds: number[];
    position: number;
}
export declare function validateDrowseCaptureRows(rows: DrowseCaptureRow[], specialTokenIds: number[]): void;
export declare function validateDrowseCapturePositions(positions: number[], tokenCount: number): void;
export declare function validateDrowseSaeDictionary(dictionary: DrowseSaeDictionary, hiddenSize: number, layerCount: number): void;
export declare function validateDrowseJlensDictionary(dictionary: DrowseJlensDictionary, hiddenSize: number, layerCount: number): void;
export declare function validateDrowseStructuredProgram(program: DrowseStructuredProgram, expectedHiddenSize: number, expectedLayerCount: number): void;
//# sourceMappingURL=drowse.d.ts.map