import type { GPUDeviceDetectOutput } from "@mlc-ai/web-runtime";
/**
 * The production device from the caller's adapter. `requiredBindingBytes` is the model's largest
 * buffer (its catalog requirement, the model record's `buffer_size_required_bytes`): the device
 * asks for exactly that `maxStorageBufferBindingSize` and `maxBufferSize` (WebGPU's defaults when
 * they are larger), so every adapter the catalog admits runs the model under the same limits, and
 * an adapter that reports less fails here, before a weight is fetched.
 */
export declare function requestGPUDeviceFromAdapter(adapter: GPUAdapter, requiredBindingBytes?: number): Promise<GPUDeviceDetectOutput>;
//# sourceMappingURL=gpu.d.ts.map