import * as tvmjs from "@mlc-ai/web-runtime";
import { Tokenizer } from "@mlc-ai/web-tokenizers";
import { ChatConfig, GenerationConfig, Role } from "./config";
import { Conversation } from "./conversation";
import { LogitProcessor, LatencyBreakdown } from "./types";
import { ChatCompletionFinishReason, ChatCompletionTokenLogprob, DrowseGenerationFinishReason, DrowseReplayLogprob } from "./openai_api_protocols/index";
import { DrowseStructuredProgram, DrowseCaptureRow, DrowsePreparedCaptureRow, DrowseResidualCapture, DrowseRuntimeCapabilities, DrowseStructuredHookProfile, DrowseSaeDictionary, DrowseJlensDictionary, DrowseJlensTopTokenReadout, DrowseMeasurementBundle, DrowseSaeTopFeatureReadout, DrowseBlockSitesRequest, DrowseBlockSitesResult } from "./drowse";
export type DrowseJlensBufferLimits = {
    maxBufferSize: number;
    maxStorageBufferBindingSize: number;
};
export type DrowseJlensChunkPlan = {
    layerIds: number[];
    byteLength: number;
};
export declare const DROWSE_JLENS_MAX_CHUNK_BYTES: number;
export declare const DROWSE_SAE_MAX_CHUNK_BYTES: number;
export declare const DROWSE_SAE_MAX_FEATURES_PER_CHUNK = 16384;
export type DrowseSaeChunkPlan = {
    featureOffset: number;
    featureCount: number;
    paddedFeatureCount: number;
    encoderByteLength: number;
};
export declare function planDrowseSaeChunks(hiddenSize: number, featureCount: number, limits: DrowseJlensBufferLimits): DrowseSaeChunkPlan[];
export declare function planDrowseJlensChunks(layerIds: readonly number[], hiddenSize: number, limits: DrowseJlensBufferLimits): DrowseJlensChunkPlan[];
export interface DrowseSamplerResult {
    sampledTokenId: number;
    sampledLogprob: number;
    selectedLogprobs: DrowseReplayLogprob[];
    argmax: DrowseReplayLogprob;
    topLogprobs: DrowseReplayLogprob[];
    entropyNats: number;
    perplexity: number;
}
export declare const DROWSE_DEFAULT_TOP_K = 1024;
export declare function effectiveDrowseTopK(topK: number, vocabSize: number): number;
export declare function sampleDrowseTopKTopP(sortedProbabilities: Float32Array, sortedTokenIds: Int32Array, topP: number, topK: number, uniformSample: number, selectedTokenIds?: readonly number[], topLogprobCount?: number): DrowseSamplerResult;
export declare class LLMChatPipeline {
    private config;
    private tokenizer;
    private tvm;
    private device;
    private vm;
    private prefill;
    private decoding;
    private drowseStructuredPrefill?;
    private drowseStructuredDecoding?;
    private drowseCurvedPrefill?;
    private drowseCurvedDecoding?;
    private drowseGeometryPrefill?;
    private drowseGeometryDecoding?;
    private drowseCapturePrefill?;
    private drowseCaptureDecoding?;
    private drowseJlensReadout?;
    private drowseJlensReadoutAccumulate?;
    private drowseJlensReadoutTopK?;
    private drowseJlensDirections?;
    private drowseSaeReadoutAccumulate?;
    private drowseSaeJumpReluReadoutAccumulate?;
    private drowseHookProfile?;
    private resolvedModelABI;
    private kvStateKind;
    private image_embed;
    private embed;
    private fapplyBitmask;
    private fapplyPenalty;
    private fapplyLogitBias;
    private fsoftmaxWithTemperature;
    private fsampleWithTopP;
    private fargsortProbs;
    private fclearKVCaches;
    private fKVCacheAddSequence;
    private fKVCacheRemoveSequence;
    private fKVCacheBeginForward;
    private fKVCacheEndForward;
    private fKVCacheEnableSlidingWindowForSeq;
    private params;
    private kvCache?;
    private rnnState?;
    private prefillLogitPositions?;
    private prefillLogitPositionHost;
    private maxHistorySize;
    private logitsOnCPU?;
    private drowseGpuTopK?;
    private drowseCurveControlKernel?;
    private drowseAffineActiveStaging?;
    private drowseAffineAlongStaging?;
    private drowseCurveActiveStaging?;
    private drowseStructuredProgram?;
    private drowsePositionSpans?;
    private drowsePositionActive;
    private drowsePositionAffine?;
    private drowsePositionCurve?;
    private drowsePositionUnit?;
    private drowseStructuredMode?;
    private drowseUnitsPrefill?;
    private drowseUnitsDecoding?;
    private drowseUnitTaps?;
    /** The installed program's `hiddenCapture`, and the last forward's `[L, d]` capture it kept. */
    private drowseHiddenCaptureRequested;
    private drowseHiddenCapture?;
    private drowseReplayPrefill?;
    private drowseAttentionRows?;
    private drowseHeadWriteGrams?;
    /** The static reads (`exact-readout-v2` and, on a units library, the unit reads). */
    private drowseReadFunctions;
    /** Buffers kept on the GPU across block-sites calls (head grams, unit scales, pattern
     *  captures), by id; dropped with the model. */
    private drowseResidents;
    private drowseResidentSerial;
    private drowseHeadGramsId?;
    private drowseReplayState?;
    private drowseUnitActiveStaging?;
    private drowseHookDescriptor?;
    private drowseAffineAlongHost?;
    private drowseCurveParametersHost?;
    private drowseMeasurements?;
    private drowseGeometryMeasurements?;
    private drowseJlensReadoutLayers;
    private drowseJlensChunks?;
    private drowseJlensDictionary?;
    private drowseJlensBufferLimits?;
    private drowseJlensProbabilitiesHost?;
    private drowseJlensTopTokensHost?;
    private drowsePendingJlensReadback?;
    private drowseSaeDictionary?;
    private drowseSaeReadoutActive;
    private drowseSaeTopFeaturesHost?;
    private drowsePendingSaeReadback?;
    private drowseMeasurementBundleHost?;
    private drowseExactReadoutAttested;
    private drowseProbeKindHost?;
    private filledKVCacheLength;
    private drowseCachedInputIds;
    private bosTokenId;
    private contextWindowSize;
    private slidingWindowSize;
    private attentionSinkSize;
    private prefillChunkSize;
    private resetStatsPerPrefill;
    private stopStr;
    private stopTokens;
    private outputMessage;
    private outputIds;
    private outputPrefix;
    private drowseRawMessage;
    private stopTriggered;
    private finishReason;
    private drowseFinishReason;
    private appearedTokensFreq;
    private imageDataCache;
    private conversation;
    private tokenLogprobArray;
    private decodingTotalTime;
    private decodingTotalTokens;
    private prefillTotalTime;
    private prefillTotalTokens;
    private curRoundDecodingTotalTokens;
    private curRoundPrefillTotalTokens;
    private curRoundDecodingTotalTime;
    private curRoundPrefillTotalTime;
    private curRoundSampledTokens;
    private curRoundDrowseCompletionTokens;
    private drowseReadoutStart;
    private drowseReadoutTarget;
    curRoundLatencyBreakdown: LatencyBreakdown;
    private logitProcessor?;
    private grammarMatcher?;
    private responseFormatCacheKey?;
    private xgTokenizerInfo?;
    private grammarCompiler?;
    private bitmaskSize;
    private fullVocabSize;
    private token_postproc_method;
    private prepend_space_in_encode;
    private curRoundGrammarInitTotalTime;
    private curRoundGrammarPerTokenTotalTime;
    private sampleIndices;
    private sampleIndicesDevice;
    private topPDevice;
    constructor(tvm: tvmjs.Instance, tokenizer: Tokenizer, config: ChatConfig, logitProcessor?: LogitProcessor, drowseJlensBufferLimits?: DrowseJlensBufferLimits);
    dispose(): void;
    supportsDrowseStructuredHooks(): boolean;
    supportsDrowseCurvedHooks(): boolean;
    /** The units pair (hook ABI v5, `standard-v4`): mean-ablation and the live unit tap. */
    supportsDrowseUnitSites(): boolean;
    supportsDrowseResidualCapture(): boolean;
    getDrowseRuntimeCapabilities(): DrowseRuntimeCapabilities;
    getDrowseStructuredHookProfile(): Promise<DrowseStructuredHookProfile>;
    /** Hook ABI v5's block-sites device surface (HOOK_ABI.md §7-§9), one request per call. */
    drowseBlockSites(request: DrowseBlockSitesRequest): Promise<DrowseBlockSitesResult>;
    private drowseBlockDims;
    private addDrowseResident;
    private requireDrowseResident;
    /** `head_grams [L, H, hd, hd]`, built once per loaded model (`drowse_head_write_grams`). */
    private drowseResidentHeadGrams;
    private uploadDrowseUnitScales;
    private releaseDrowseResident;
    /** The dtype a host tensor uploads as, after checking its length against its shape. */
    private drowseTensorDtype;
    /** §8 residency: one lens matrix `[1, d, d]`, or the S embedding statistics
     *  (`mean_E [d]`, `Σ_E [d, d]`, mask `[ceil(V / 32)]`). */
    private uploadDrowseResident;
    /** §8: run static-read steps on the device and read the named outputs back with one sync. */
    private runDrowseReads;
    /** Open a KV-continuing replay (B1 §2.3, HOOK_ABI.md §7) on a fresh sequence. The installed
     *  program (drowse-structured-v4 with a unit section) steers it; `replayMeta` names the taps. */
    private openDrowseReplay;
    private requireDrowseReplay;
    /** Feed one logical segment under one control state, in forwards of at most
     *  `prefill_chunk_size` rows; returns what its last forward gives the next segment's gates
     *  (one sync): probe slots (J-lens kind 3 included), unit taps, the geometry readout and,
     *  when the program asks, the `[L, d]` capture. */
    private forwardDrowseReplay;
    /** Read the captures back (one sync), keep the pattern capture resident, drop the sequence. */
    private finishDrowseReplay;
    private cancelDrowseReplay;
    private disposeDrowseReplay;
    /** `a_j = softmax_j(q_p·k_j·scaling)` for `rows` (`[16, 4]`: slot, layer, head, p; slot −1
     *  unused) of a resident pattern capture → `[16, T]` (`drowse_attention_rows`). */
    private readDrowseAttentionRows;
    tokenizeDrowseText(text: string): number[];
    decodeDrowseTokens(tokenIds: readonly number[]): string;
    prepareDrowseCaptureRows(rows: DrowseCaptureRow[], specialTokenIds: number[]): DrowsePreparedCaptureRow[];
    captureDrowseResiduals(inputIds: number[], positions: number[]): Promise<DrowseResidualCapture>;
    setDrowseStructuredProgram(program: DrowseStructuredProgram): Promise<void>;
    updateDrowseStructuredControls(affineActive: Uint32Array, curveActive?: Uint32Array, unitActive?: Float32Array): Promise<void>;
    private writeDrowseStructuredControls;
    setDrowseSaeDictionary(dictionary: DrowseSaeDictionary): Promise<void>;
    clearDrowseSaeDictionary(): Promise<void>;
    setDrowseJlensDictionary(dictionary: DrowseJlensDictionary): Promise<void>;
    clearDrowseJlensDictionary(): Promise<void>;
    readDrowseJlensTopTokens(): Promise<DrowseJlensTopTokenReadout | undefined>;
    readDrowseSaeTopFeatures(): Promise<DrowseSaeTopFeatureReadout | undefined>;
    /** Remove the installed hook program, leaving the model unsteered. */
    clearDrowseProgram(): void;
    readDrowseMeasurementBundle(): Promise<DrowseMeasurementBundle>;
    readDrowseMeasurements(): Promise<Float32Array | undefined>;
    readDrowseGeometryMeasurements(): Promise<Float32Array | undefined>;
    resolveDrowseJlensTokenDirections(bindingId: string, layerIndices: readonly number[], tokenIds: readonly number[]): Promise<Float32Array>;
    private drowseDiscoveryRequested;
    private computeDrowseJlensProbabilities;
    private computeDrowseJlensProbabilitiesAndTopTokens;
    private uploadDrowseJlensChunks;
    private uploadDrowseSaeDictionary;
    private computeDrowseSaeTopFeatures;
    private materializeDrowseJlensReadback;
    private materializeDrowseSaeReadback;
    private disposeDrowsePendingJlensReadback;
    private disposeDrowsePendingSaeReadback;
    private disposeDrowsePendingReadbacks;
    private resetDrowseReadbackState;
    private requireDrowseTensorShape;
    private requireDrowseJlensBufferLimits;
    private selectDrowseJlensChunks;
    private requireDrowseExactReadout;
    private requireModelDimension;
    private disposeDrowseProgram;
    private disposeDrowseJlensDictionary;
    private disposeDrowseSaeDictionary;
    /**
     * Get the current message.
     */
    getMessage(): string;
    /** Return the monotonically decoded generated tokens before stop-string trimming. */
    getDrowseRawMessage(): string;
    /**
     * Reset the runtime statistics
     */
    resetRuntimeStats(): void;
    /**
     * Reset the chat history
     */
    resetChat(keepStats?: boolean): void;
    /**
     * Reset KV Cache
     */
    resetKVCache(): void;
    /**
     * @returns Whether stop is triggered.
     */
    stopped(): boolean;
    /**
     * @returns Finish reason; undefined if generation not started/stopped yet.
     */
    getFinishReason(): ChatCompletionFinishReason | undefined;
    getDrowseFinishReason(): DrowseGenerationFinishReason | undefined;
    /**
     * @returns tokenLogprobArray for this current round of autoregressive generation.
     * Updated upon each sampled token, cleared upon each prefillStep().
     */
    getTokenLogprobArray(): Array<ChatCompletionTokenLogprob>;
    /**
     * @returns the number of tokens decoded for a single request or a single choice in the request.
     */
    getCurRoundDecodingTotalTokens(): number;
    getCurRoundDrowseCompletionTokens(): number;
    /**
     * @returns the number of tokens decoded for a single request or a single choice in the request.
     */
    getCurRoundPrefillTotalTokens(): number;
    /**
     * @returns the time spent on decode for a single request or a single choice in the request.
     */
    getCurRoundDecodingTotalTime(): number;
    /**
     * @returns the time spent on  for a single request or a single choice in the request.
     */
    getCurRoundPrefillTotalTime(): number;
    /**
     * @returns the time (seconds) spent on for initializing grammar matcher for a single request.
     */
    getCurRoundGrammarInitTotalTime(): number;
    /**
     * @returns the total time (seconds) spent on creating bitmask and accepting token grammar matcher
     * for all the generated tokens in a single request.
     */
    getCurRoundGrammarPerTokenTotalTime(): number;
    /**
     * @returns the breakdown of latencies for sampling each token for a single request.
     */
    getCurRoundLatencyBreakdown(): LatencyBreakdown;
    /**
     * @returns Runtime stats information.
     */
    runtimeStatsText(): string;
    /**
     * @returns Runtime stats information, starting from the last prefill performed.
     */
    curRoundRuntimeStatsText(): string;
    /**
     * @returns Prefill tokens per second, starting from the last prefill performed.
     */
    getCurRoundPrefillTokensPerSec(): number;
    /**
     * @returns Prefill tokens per second, starting from the last prefill performed.
     */
    getCurRoundDecodingTokensPerSec(): number;
    /**
     * Set the seed for the RNG `this.tvm.rng`.
     */
    setSeed(seed: number): void;
    private getResponseFormatKey;
    /**
     * @returns The conversation object (not a deep copy).
     */
    getConversationObject(): Conversation;
    /**
     * Set this.conversation to a new conversation object.
     */
    setConversation(newConv: Conversation): void;
    asyncLoadWebGPUPipelines(): Promise<void>;
    /**
     * Generate the first token given input prompt
     */
    prefillStep(inp: string, msgRole: Role, inp_role_str?: string, genConfig?: GenerationConfig): Promise<void>;
    decodeStep(genConfig?: GenerationConfig): Promise<void>;
    /**
     * Manually trigger stop if it is not stopped.
     */
    triggerStop(): void;
    /**
     * Add a generated token and check for stop.
     *
     * @param nextToken The next token.
     * @param genConfig Configs that override `this.config` for this round of generation.
     */
    private processNextToken;
    /**
     * Given input tokens, return embeddings of them by calling embed kernel.
     *
     * @note precondition: inputTokens.length <= prefillChunkSize, since we take care of
     * chunking in `getChunkedPrefillInputData()`.
     */
    private getTokensEmbeddings;
    /**
     * Compute the number of embedding tokens an image will produce.
     * Must match the model's image_embed output size.
     * Based on mlc_llm/serve/data.py _compute_embed_size.
     */
    private computeImageEmbedSize;
    /**
     * Calculate resize dimensions per model type.
     * Based on vlm_utils.cc CalculateResizeShape
     */
    private calculateResizeShape;
    /**
     * Calculate crop dimensions per model type.
     * Based on vlm_utils.cc CalculateCropShape / CalculatePadShape
     */
    private calculateCropShape;
    /**
     * Embed an image input.
     */
    private getImageEmbeddings;
    /**
     * Embed and forward input data, that can be either array of tokens, or an image.
     * This will increment `this.filledKVCacheLength`.
     *
     * @param inputData data to embed and forward
     * @param inputDataLen length of this inputData, should smaller than prefill chunk size.
     * @returns The logits returned by this forward as tvmjs.Tensor on GPU.
     *
     * @note Precondition: inputData's data length is smaller than prefill chunk size
     */
    private embedAndForward;
    private applyDrowsePositionControls;
    private embedAndForwardChunk;
    private static loadVMFunctionRegistry;
    private static getRequiredVMFunctionByName;
    private static getVMFunctionAvailability;
    private parseKVStateKind;
    private static resolveModelABI;
    private requireKVCache;
    private requireRNNState;
    private getSingleStateForABI;
    private getActiveKVStates;
    private drowseStateArguments;
    private drowseOutputOffset;
    private resetDrowseCaptureState;
    private captureDrowseTokenChunk;
    private invokeDrowseCapture;
    private invokePrefill;
    private invokeDecode;
    private getDrowseForwardArguments;
    private getDrowseGeometryArguments;
    private updateLogitsOnCPU;
    private sampleTokenFromLogits;
    private commitSampledToken;
    /**
     * Return the an array of a mixture of token arrays and imageURLs (which cannot be represented
     * as tokens). Also return the number of tokens this represents.
     *
     * We first convert the Conversation into a prompt array to be prefilled. Then we encode the
     * text parts, leaving the imageURLs as it is.
     * Example prompts:
     * [
     *   "<|system|>\nSome system prompt\n",
     *   [
     *     "<|user|>\n",
     *     imageURL1,
     *     "\n",
     *     imageURL2,
     *     "\n",
     *     "Some user input<|end|>\n"
     *   ],
     * ]
     *
     * Expected output:
     * [
     *   token array for "<|system|>\nSome system prompt\n<|user|>\n",
     *   imageUrl1,
     *   token array for "\n",
     *   imageUrl2,
     *   token array for "\nSome user input<|end|>\n"
     */
    private getInputData;
    forwardTokensAndSample(inputIds: Array<number>, isPrefill: boolean): Promise<number>;
    /**
     * Based on `emittedToken` and `this.logitsOnCPU`, which becomes a distribution after
     * calling `this.tvm.applySoftmaxWithTemperature()`, generate `ChatCompletionTokenLogprob` and
     * update `this.tokenLogprobArray`.
     *
     * @param emittedToken The token ID emitted after any Drowse forced replay override.
     * @param top_logprobs Number of top tokens to include; `top_logprobs` in `ChatCompletionRequest`.
     *
     * @return The `ChatCompletionTokenLogprob` for this single autoregressive step.
     */
    private getTokenLogprob;
    /**
     * Synchronize the device.
     */
    sync(): Promise<void>;
    evaluate(): Promise<void>;
}
//# sourceMappingURL=llm_chat.d.ts.map